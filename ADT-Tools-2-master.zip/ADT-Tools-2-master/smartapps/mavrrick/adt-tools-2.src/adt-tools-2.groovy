/**
 *  ADT Tools 2.0
 *
 *  Copyright 2018 CRAIG KING
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
definition(
    name: "ADT Tools 2",
    namespace: "Mavrrick",
    author: "CRAIG KING",
    description: "Smartthing ADT tools for additional functions ",
    category: "Safety & Security",
    iconUrl: "https://lh4.googleusercontent.com/-1dmLp--W0OE/AAAAAAAAAAI/AAAAAAAAEYU/BRuIXPPiOmI/s0-c-k-no-ns/photo.jpg",
    iconX2Url: "https://lh4.googleusercontent.com/-1dmLp--W0OE/AAAAAAAAAAI/AAAAAAAAEYU/BRuIXPPiOmI/s0-c-k-no-ns/photo.jpg",
    iconX3Url: "https://lh4.googleusercontent.com/-1dmLp--W0OE/AAAAAAAAAAI/AAAAAAAAEYU/BRuIXPPiOmI/s0-c-k-no-ns/photo.jpg",
    singleInstance: true)

/* 
* Initial release v2.0.0
*
* 12/25/2018 v2.0.0.a
* Update routine to disarm Location alarm state to unschedule other location alarm events if needed.
*
* 1/16/2019 2.0.1
* Add Monitor and action for alarm tamper and power event
*
* 1/30/2019 2.0.2
* Updated notification routine to allow for usage of multiple SMS numbers.
*
*/

preferences
{
	page (name: "mainPage", title: "ADT Tools")
	page (name: "adtNotifier", title: "ADT Custom Notification")
	page (name: "adtModeChange", title: "Setup mode change settings")
	page (name: "adtAlertActions", title: "Work with ADT alarm alert actions")
   	page (name: "optionalSettings", title: "Optional Setup")
    page (name: "about", title: "About ADT Tools")
}

def initialize() {
    // nothing needed here, since the child apps will handle preferences/subscriptions
    // this just logs some messages for demo/information purposes
    log.debug "there are ${childApps.size()} child smartapps"
    childApps.each {child ->
        log.debug "child app: ${child.label}"
    }
    if (settings.createVirtButton) {
    				log.debug "initialize: Creating virtual button devices ADT Mode Change"
				addChildDevice("Mavrrick", "ADT Tools Button", "ADT Tools Disarmed", location.hubs[0].id, [
					"name": "ADT Tools Disarmed",
					"label": "ADT Tools Disarmed",
					"completedSetup": true, 					
				])
                				addChildDevice("Mavrrick", "ADT Tools Button", "ADT Tools Armed Stay", location.hubs[0].id, [
					"name": "ADT Tools Armed Stay",
					"label": "ADT Tools Armed Stay",
					"completedSetup": true, 					
				])
                				addChildDevice("Mavrrick", "ADT Tools Button", "ADT Tools Armed Away", location.hubs[0].id, [
					"name": "ADT Tools Armed Away",
					"label": "ADT Tools Armed Away",
					"completedSetup": true, 					
				])
                log.debug "ADT Tools Alarm Buttons created"
                }
	}


/*
	mainPage

	UI Page: Main menu for the app.
*/
def mainPage()
{
	dynamicPage(name: "mainPage", title: "ADT Tools Main Menu", uninstall: true, install: true)
	{
		section("ADT Integration Smartapps")
		{
			href "adtNotifier", title: "Alarm Status Notifications", description: "Setup Custom notifications for alarm system status changes."
            href "adtModeChange", title: "ADT Smartthings Alarm Mode change integration", description: "Enables various functions around Mode change integration."
		}

		section("Alert Apps")
		{
			href "adtAlertActions", title: "Integration Alert Actions", description: "Setup Integration alert actions."
		}
		section("ADT Tools basic setup")
		{
			href "optionalSettings", title: "Optional setup steps", description: "Setup ADT Automation standard buttons."
			href "about", title: "About ADT Tools ", description: "Support the project...  Consider making a small contribution today!"
		}
	}
}

def adtNotifier()
{
	dynamicPage(name: "adtNotifier", title: "ADT Custon Notifications", uninstall: false, install: false)
	{
	section("Set Message for each state"){
		input "messageDisarmed", "text", title: "Send this message if alarm changes to Disarmed", required: false
        input "messageArmedAway", "text", title: "Send this message if alarm changes to Armed/Away", required: false
        input "messageArmedStay", "text", title: "Send this message if alarm changes to Armed/Stay", required: fals
        input "alarmPowerState", "bool", title: "Power State Notification", description: "This switch will tell ADT Tools to notify you when the Smartthings Panel change power sources between battery and home power", defaultValue: false, required: true, multiple: false
   		input "alarmTamperState", "bool", title: "Tamper Activity Notification", description: "This switch will tell ADT Tools to notify you if any tamper activty is detected on the Smartthings Alarm Panel", defaultValue: false, required: true, multiple: false

	}
	section("Via a push notification and/or an SMS message"){
		input("recipients", "contact", title: "Send notifications to") {
        	paragraph "Multiple numbers can be entered as long as sperated by a (;)"
			input "phone", "phone", title: "Enter a phone number to get SMS", required: false
			paragraph "If outside the US please make sure to enter the proper country code."
			input "sendPush", "enum", title: "Send Push notifications to everyone?", required: false, options: ["Yes", "No"]
		}
	}
	section("Minimum time between messages (optional, defaults to every message)") {
		input "frequency", "decimal", title: "Minutes", required: false
	}
    section ("Return to ADT Tools Main page"){
        href "mainPage", title: "ADT Tools Main Menu", description: "Return to main ADT Tools Main Menu"            
    }
	}
}

def adtModeChange()
{
	dynamicPage(name: "adtModeChange", title: "ADT Mode Change Integration", uninstall: false, install: false)
    {
	section("Select what button you want for each mode..."){
        input "myDisarmButton", "capability.momentary", title: "What Button will disarm the alarm?", required: false, multiple: false
        input "myArmStay", "capability.momentary", title: "What button will put the alarm in Armed/Stay?", required: false, multiple: false
        input "myArmAway", "capability.momentary", title: "What button will put the alarm in Armed/Away?", required: false, multiple: false
	}
   section("Smartthings location alarm state setup. These must be configured to use the Any Sensory Child App."){
   		input "locAlarmSync", "bool", title: "Maintain synchronization between Smartthings ADT alarm panel and location clound alarm state", description: "This switch will tell ADT Tools if it needs to kep the ADT Alarm and the Smarthings location alarm status in sync.", defaultValue: false, required: true, multiple: false
		input "delay", "number", range: "1..120", title: "Please specify your Alarm Delay", required: true, defaultValue: 0
	}
    
	section("Select your ADT Smart Panel..."){
		input "panel", "capability.securitySystem", title: "Select ADT Panel for Alarm Status", required: true
	}
    section ("Return to ADT Tools Main page"){
            href "mainPage", title: "ADT Tools Main Menu", description: "Return to main ADT Tools Main Menu"            
		}
    }
}

def adtAlertActions()
{
	dynamicPage(name: "adtAlertActions", title: "ADT Alert Actions ", uninstall: false, install: false)
    {
        section ("Alarm Event Action Apps"){
            app(name: "adtAlertAction", appName: "ADT Alert Action", namespace: "Mavrrick", title: "Security Alert Action apps", multiple: true)
            app(name: "adtHomeAction", appName: "ADT Home-Life Alert Action", namespace: "Mavrrick", title: "Home/Life Alert Action apps", multiple: true)
		}
        section ("Return to ADT Tools Main page"){
            href "mainPage", title: "ADT Tools Main Menu", description: "Return to main ADT Tools Main Menu"            
		}
    }
}

def optionalSettings()
{
	dynamicPage(name: "optionalSettings", title: "Optional settings", uninstall: false, install: false)
	{
        section ("Virtual Button Setup"){
	   		input "createVirtButton", "bool", title: "Would you like ADT Tools to create your virtual buttons for Mode change functianlity", description: "ADT Tools will attempt to create virtual devices for the mode change functinality", defaultValue: false, required: true, multiple: false
		}
        section ("Return to ADT Tools Main page"){
            href "mainPage", title: "ADT Tools Main Menu", description: "Return to main ADT Tools Main Menu"            
		}
	}
}

def about()
{
	dynamicPage(name: "about", title: "About ADT Tools", uninstall: false, install: false)
	{
		section()
		{
			paragraph image: "https://lh4.googleusercontent.com/-1dmLp--W0OE/AAAAAAAAAAI/AAAAAAAAEYU/BRuIXPPiOmI/s0-c-k-no-ns/photo.jpg", "ADT Tools 2"
		}
        section("Support locations")
		{
			href "thingsAreSmart", style:"embedded", title: "Things That Are Smart Support Page", url: "http://thingsthataresmart.wiki/index.php?title=ADT_tools_2"
			href "smtReleaseThd", style:"embedded", title: "Smartthings Community Support Thread", url: "https://community.smartthings.com/t/released-adt-tools-2-for-smartthings-adt-alarm-sytsems/124951"
		}
        section("Support the Project")
		{
			paragraph "ADT Tools is provided free for personal and non-commercial use.  I have worked on this app in my free time to fill the needs I have found for myself and others like you.  I will continue to make improvements where I can. If you would like you can donate to continue to help with development please use the link below."
			href "donate", style:"embedded", title: "Consider making a \$5 or \$10 donation today.", image: "https://storage.googleapis.com/arlopilot/donate-icon.png", url: "https://www.paypal.me/mavrrick58"
		}
        section ("Return to ADT Tools Main page"){
            href "mainPage", title: "ADT Tools Main Menu", description: "Return to main ADT Tools Main Menu"            
		}
	}
}

def installed() {
	log.debug "Installed with settings: ${settings}"
	subscribeToEvents()
    initialize()
}

def updated() {
	log.debug "Updated with settings: ${settings}"
	unsubscribe()
	subscribeToEvents()
    initialize()
}

def uninstalled() {
    // external cleanup. No need to unsubscribe or remove scheduled jobs
    	// 1.4 Remove dead virtual devices
	getChildDevices()?.each
	{childDevice ->
			deleteChildDevice(childDevice.deviceNetworkId)
		}
	}

def subscribeToEvents() {
    subscribe(myDisarmButton, "momentary.pushed", disarmHandler)
    subscribe(myArmStay, "momentary.pushed", armstayHandler)
    subscribe(myArmAway, "momentary.pushed", armawayHandler)
    subscribe(location, "securitySystemStatus", alarmModeHandler)
    if (settings.alarmPowerState) {       
        subscribe(panel, "powerSource", adtPowerHandler)
		}
    if (settings.alarmTamperState) {       
        subscribe(panel, "tamper", adtTamperHandler)
		}
}

def msg = "" 

def disarmHandler(evt) {
      log.debug "Disarming alarm"
      panel?.disarm()
	}

def armstayHandler(evt) {
       log.debug "Changeing alarm to Alarm/Stay"
       def alarmState = panel.currentSecuritySystemStatus
        if (alarmState == "armedAway") {
        	log.debug "Current alarm mode: ${alarmState}. Alarm must be in Disarmed state before changeing state"
        }
        else {       
        panel?.armStay(armedStay)

        }
	}
    
def armawayHandler(evt) {
       	log.debug "Changeing alarm to Alarm/Away"
        def alarmState = panel.currentSecuritySystemStatus
        if (alarmState == "armedStay") {
        	log.debug "Current alarm mode: ${alarmState}. Alarm must be in Disarmed state before changeing state"
        }
        else {
      	panel?.armAway(armedAway)}
	   }

def alarmModeHandler(evt) {
	log.debug "Notify got evt ${evt}"
	if (frequency) {
		def lastTime = state[evt.deviceId]
		if (lastTime == null || now() - lastTime >= frequency * 60000) {
			sendMessage(evt)
		}
	}
	else {
		sendMessage(evt)
	}
	    if (settings.locAlarmSync) 
		{
	switch (evt.value)
        	{
            	case "armedAway":
        			runIn(delay, armawaySHMHandler)
                    break
                case "armedStay":
                	log.debug "Attempting change of Hub alarm Mode"
                    runIn(delay, armstaySHMHandler)
                    break
                case "disarmed" :
                    sendLocationEvent(name: "alarmSystemStatus", value: "off")
					unschedule()
                    break
                default:
					log.debug "Ignoring unexpected alarmtype mode."
        			log.debug "Unexpected value for Alarm status"
                    break
                    }
        }
}

def armstaySHMHandler() {
       	log.debug "Changeing HUB alarm state to Armed/Stay"
        sendLocationEvent(name: "alarmSystemStatus", value: "stay")
	   }
       
def armawaySHMHandler() {
       	log.debug "Changeing HUB alarm state to Alarm/Away"
        sendLocationEvent(name: "alarmSystemStatus", value: "away")
	   } 

private sendMessage(evt) {

switch (evt.value)
    {
    case "armedAway":
    	def msg = messageArmedAway
           if ( msg == null ) {
        	log.debug "Message not configured. Skipping notification"
            }
        else {
    if (phone) { // check that the user did select a phone number
        if ( phone.indexOf(";") > 0){
            def phones = phone.split(";")
            for ( def i = 0; i < phones.size(); i++) {
                log.debug("Sending SMS ${i+1} to ${phones[i]}")
                sendSmsMessage(phones[i], msg)
            }
        } else {
            log.debug("Sending SMS to ${phone}")
            sendSmsMessage(phone, msg)
        }
    } else if (settings.sendPush) {
        log.debug("Sending Push to everyone")
        sendPushMessage(msg)
    }
    sendNotificationEvent(msg)	
    }
    break
    case "armedStay":
    	def msg = messageArmedStay
        if ( msg == null ) {
        	log.debug "Message not configured. Skipping notification"
            }
        else {
        log.debug "Case Armstay., '$msg'"
        log.debug "$evt.name:$evt.value, sendPush:$sendPush, '$msg'"
   if (phone) { // check that the user did select a phone number
        if ( phone.indexOf(";") > 0){
            def phones = phone.split(";")
            for ( def i = 0; i < phones.size(); i++) {
                log.debug("Sending SMS ${i+1} to ${phones[i]}")
                sendSmsMessage(phones[i], msg)
            }
        } else {
            log.debug("Sending SMS to ${phone}")
            sendSmsMessage(phone, msg)
        }
    } else if (settings.sendPush) {
        log.debug("Sending Push to everyone")
        sendPushMessage(msg)
    }
    sendNotificationEvent(msg)	
    }
	break
    case "disarmed":
    	def msg = messageDisarmed
        if ( msg == null ) {
        	log.debug "Message not configured. Skipping notification"
            }
        else {
        log.debug "Case disarmed., '$msg'"
        log.debug "$evt.name:$evt.value, sendPush:$sendPush, '$msg'"
   if (phone) { // check that the user did select a phone number
        if ( phone.indexOf(";") > 0){
            def phones = phone.split(";")
            for ( def i = 0; i < phones.size(); i++) {
                log.debug("Sending SMS ${i+1} to ${phones[i]}")
                sendSmsMessage(phones[i], msg)
            }
        } else {
            log.debug("Sending SMS to ${phone}")
            sendSmsMessage(phone, msg)
        }
    } else if (settings.sendPush) {
        log.debug("Sending Push to everyone")
        sendPushMessage(msg)
    }
    sendNotificationEvent(msg)	
    }
	break
    default:
		log.debug "Ignoring unexpected ADT alarm mode."
        log.debug "$evt.name:$evt.value, sendPush:$sendPush, '$msg'"
        break
}
}

def adtPowerHandler(evt) {
       	log.debug "ADT Smartthigs Alarm Panel has changed power sources to ${evt}. "
        
        switch (evt.value){
        case "mains":
       	def msg = "The alarm has changed to run on main power"
        log.debug "$evt.name:$evt.value, sendPush:$sendPush, '$msg'"
   if (phone) { // check that the user did select a phone number
        if ( phone.indexOf(";") > 0){
            def phones = phone.split(";")
            for ( def i = 0; i < phones.size(); i++) {
                log.debug("Sending SMS ${i+1} to ${phones[i]}")
                sendSmsMessage(phones[i], msg)
            }
        } else {
            log.debug("Sending SMS to ${phone}")
            sendSmsMessage(phone, msg)
        }
    } else if (settings.sendPush) {
        log.debug("Sending Push to everyone")
        sendPushMessage(msg)
    }
    sendNotificationEvent(msg)	
		break
        case "battery":
       	def msg = "The alarm has changed to run on battery power"
        log.debug "$evt.name:$evt.value, sendPush:$sendPush, '$msg'"

   if (phone) { // check that the user did select a phone number
        if ( phone.indexOf(";") > 0){
            def phones = phone.split(";")
            for ( def i = 0; i < phones.size(); i++) {
                log.debug("Sending SMS ${i+1} to ${phones[i]}")
                sendSmsMessage(phones[i], msg)
            }
        } else {
            log.debug("Sending SMS to ${phone}")
            sendSmsMessage(phone, msg)
        }
    } else if (settings.sendPush) {
        log.debug("Sending Push to everyone")
        sendPushMessage(msg)
    }
    sendNotificationEvent(msg)	
		break
        default:
		log.debug "Ignoring unexpected power state ${evt.value}."
        log.debug "$evt.name:$evt.value, sendPush:$sendPush, '$msg'"
        break
	   }
       }
       
def adtTamperHandler(evt) {
       	log.debug "ADT Smartthigs Alarm Panel has experiencend a tamper event ${evt}. "
        
        switch (evt.value){
        case "detected":
       	def msg = "The ADT Smartthings Alarm Panel has experienced a tamper event. Please check your device."
        log.debug "$evt.name:$evt.value, sendPush:$sendPush, '$msg'"

   if (phone) { // check that the user did select a phone number
        if ( phone.indexOf(";") > 0){
            def phones = phone.split(";")
            for ( def i = 0; i < phones.size(); i++) {
                log.debug("Sending SMS ${i+1} to ${phones[i]}")
                sendSmsMessage(phones[i], msg)
            }
        } else {
            log.debug("Sending SMS to ${phone}")
            sendSmsMessage(phone, msg)
        }
    } else if (settings.sendPush) {
        log.debug("Sending Push to everyone")
        sendPushMessage(msg)
    }
    sendNotificationEvent(msg)	
		break
        case "clear":
       	def msg = "The tamper event on your ADT Smartthings Panel has cleared."
        log.debug "$evt.name:$evt.value, sendPush:$sendPush, '$msg'"

   if (phone) { // check that the user did select a phone number
        if ( phone.indexOf(";") > 0){
            def phones = phone.split(";")
            for ( def i = 0; i < phones.size(); i++) {
                log.debug("Sending SMS ${i+1} to ${phones[i]}")
                sendSmsMessage(phones[i], msg)
            }
        } else {
            log.debug("Sending SMS to ${phone}")
            sendSmsMessage(phone, msg)
        }
    } else if (settings.sendPush) {
        log.debug("Sending Push to everyone")
        sendPushMessage(msg)
    }
    sendNotificationEvent(msg)	
		break
        default:
		log.debug "Ignoring unexpected tamper condition ${evt.value}."
        log.debug "$evt.name:$evt.value, sendPush:$sendPush, '$msg'"
        break
	   }
       }       